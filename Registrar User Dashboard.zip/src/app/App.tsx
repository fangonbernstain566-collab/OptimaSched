import { useState, useMemo } from "react";
import {
  LayoutDashboard,
  GraduationCap,
  LogOut,
  ChevronRight,
  ChevronLeft,
  ChevronDown,
  ChevronUp,
  UserCheck,
  CalendarDays,
  FileBadge,
  Users,
  BookOpen,
  Clock,
  Search,
  Filter,
  MoreHorizontal,
  Plus,
  X,
  CheckCircle,
  AlertCircle,
  MinusCircle,
} from "lucide-react";

// ─── Types ─────────────────────────────────────────────────────────────────────

type Page = "dashboard" | "manage-faculty" | "manage-classlist" | "view-schedule";

type NavItem = {
  icon: React.ReactNode;
  label: string;
  key: Page;
};

// ─── Nav ───────────────────────────────────────────────────────────────────────

const NAV_ITEMS: NavItem[] = [
  { icon: <LayoutDashboard size={17} />, label: "Dashboard", key: "dashboard" },
  { icon: <Users size={17} />, label: "Manage Faculty", key: "manage-faculty" },
  { icon: <BookOpen size={17} />, label: "Manage Class List", key: "manage-classlist" },
  { icon: <CalendarDays size={17} />, label: "View Schedule", key: "view-schedule" },
];

// ─── Dashboard data ────────────────────────────────────────────────────────────

const DASHBOARD_STATS = [
  { title: "Total Enrolled Students", value: 1284, badge: "Currently Enrolled", iconBg: "bg-blue-100", icon: <UserCheck size={20} className="text-blue-500" /> },
  { title: "Pending Document Requests", value: 37, badge: "Awaiting Processing", iconBg: "bg-purple-100", icon: <FileBadge size={20} className="text-purple-500" /> },
  { title: "Graduating Students", value: 312, badge: "This Academic Year", iconBg: "bg-pink-100", icon: <GraduationCap size={20} className="text-pink-500" /> },
  { title: "Pending Grade Submissions", value: 8, badge: "Faculty Pending", iconBg: "bg-red-100", icon: <CalendarDays size={20} className="text-red-500" /> },
];

// ─── Faculty data ──────────────────────────────────────────────────────────────

type FacultyStatus = "Active" | "On Leave" | "Inactive";

type Faculty = {
  id: string;
  name: string;
  department: string;
  email: string;
  subjects: string[];
  status: FacultyStatus;
  units: number;
};

const FACULTY_LIST: Faculty[] = [
  { id: "FAC-001", name: "Dr. Elena Reyes", department: "Computer Science", email: "e.reyes@pclu.edu.ph", subjects: ["CS 301", "CS 410", "CS 501"], status: "Active", units: 9 },
  { id: "FAC-002", name: "Prof. Marco Santos", department: "Engineering", email: "m.santos@pclu.edu.ph", subjects: ["ENGR 205", "ENGR 310"], status: "Active", units: 6 },
  { id: "FAC-003", name: "Dr. Jasmine Cruz", department: "Business", email: "j.cruz@pclu.edu.ph", subjects: ["BUS 101", "BUS 402", "BUS 310"], status: "Active", units: 9 },
  { id: "FAC-004", name: "Prof. Andres Villanueva", department: "Arts & Sciences", email: "a.villanueva@pclu.edu.ph", subjects: ["ARTS 110", "ARTS 220"], status: "On Leave", units: 0 },
  { id: "FAC-005", name: "Dr. Sofia Lim", department: "Medicine", email: "s.lim@pclu.edu.ph", subjects: ["MED 301", "MED 401"], status: "Active", units: 6 },
  { id: "FAC-006", name: "Atty. Ramon dela Cruz", department: "Law", email: "r.delacruz@pclu.edu.ph", subjects: ["LAW 201", "LAW 305"], status: "Active", units: 6 },
  { id: "FAC-007", name: "Prof. Maria Aquino", department: "Computer Science", email: "m.aquino@pclu.edu.ph", subjects: ["CS 101", "CS 202"], status: "Active", units: 6 },
  { id: "FAC-008", name: "Dr. Luis Mendoza", department: "Engineering", email: "l.mendoza@pclu.edu.ph", subjects: ["ENGR 101", "ENGR 205", "ENGR 401"], status: "Inactive", units: 0 },
  { id: "FAC-009", name: "Prof. Carla Torres", department: "Business", email: "c.torres@pclu.edu.ph", subjects: ["BUS 201", "BUS 305"], status: "Active", units: 6 },
  { id: "FAC-010", name: "Dr. Kevin Ong", department: "Arts & Sciences", email: "k.ong@pclu.edu.ph", subjects: ["SCI 101", "SCI 202", "SCI 310"], status: "Active", units: 9 },
];

const DEPARTMENTS = ["All", "Computer Science", "Engineering", "Business", "Arts & Sciences", "Medicine", "Law"];

// ─── Class List data ───────────────────────────────────────────────────────────

type StudentStatus = "Regular" | "Irregular";

type ClassStudent = {
  studentNo: string;
  name: string;
  course: string;
  yearLevel: string;
  section: string;
  subject: string;
  status: StudentStatus;
  grade: string | null;
};

const CLASS_STUDENTS: ClassStudent[] = [
  { studentNo: "2021-10342", name: "Maria Santos", course: "BSCS", yearLevel: "3rd Year", section: "CS-3A", subject: "CS 301", status: "Regular", grade: null },
  { studentNo: "2021-10891", name: "Juan dela Cruz", course: "BSCS", yearLevel: "3rd Year", section: "CS-3A", subject: "CS 301", status: "Regular", grade: null },
  { studentNo: "2022-20481", name: "Aisha Reyes", course: "BSCS", yearLevel: "3rd Year", section: "CS-3A", subject: "CS 301", status: "Irregular", grade: null },
  { studentNo: "2021-11203", name: "Carlos Mendoza", course: "BSCS", yearLevel: "3rd Year", section: "CS-3A", subject: "CS 301", status: "Regular", grade: null },
  { studentNo: "2021-10556", name: "Sofia Lim", course: "BSCS", yearLevel: "3rd Year", section: "CS-3A", subject: "CS 301", status: "Regular", grade: null },
  { studentNo: "2022-21100", name: "Marco Villanueva", course: "BSCS", yearLevel: "2nd Year", section: "CS-2B", subject: "CS 202", status: "Regular", grade: null },
  { studentNo: "2022-21834", name: "Rina Aquino", course: "BSCS", yearLevel: "2nd Year", section: "CS-2B", subject: "CS 202", status: "Regular", grade: null },
  { studentNo: "2023-30021", name: "Patrick Flores", course: "BSCS", yearLevel: "1st Year", section: "CS-1A", subject: "CS 101", status: "Regular", grade: null },
  { studentNo: "2023-30452", name: "Leah Castillo", course: "BSCS", yearLevel: "1st Year", section: "CS-1A", subject: "CS 101", status: "Regular", grade: null },
  { studentNo: "2022-20900", name: "Bryan Tan", course: "BSCS", yearLevel: "2nd Year", section: "CS-2B", subject: "CS 202", status: "Irregular", grade: null },
  { studentNo: "2021-12004", name: "Grace Navarro", course: "BSCS", yearLevel: "3rd Year", section: "CS-3A", subject: "CS 301", status: "Regular", grade: null },
  { studentNo: "2023-31100", name: "Jericho Ramos", course: "BSCS", yearLevel: "1st Year", section: "CS-1A", subject: "CS 101", status: "Regular", grade: null },
];

const SUBJECT_OPTIONS = ["All Subjects", "CS 101", "CS 202", "CS 301", "CS 410"];
const SECTION_OPTIONS = ["All Sections", "CS-1A", "CS-2B", "CS-3A"];

// ─── Schedule data ─────────────────────────────────────────────────────────────

type ScheduleBlock = {
  subject: string;
  section: string;
  faculty: string;
  room: string;
  color: string;
};

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const TIME_SLOTS = [
  "7:00 AM", "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM",
  "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM",
];

type ScheduleMap = Record<string, Record<string, ScheduleBlock | null>>;

const SCHEDULE: ScheduleMap = {
  "Monday": {
    "7:00 AM": { subject: "CS 101", section: "CS-1A", faculty: "Prof. Aquino", room: "Room 201", color: "bg-blue-100 text-blue-800 border-blue-200" },
    "9:00 AM": { subject: "CS 301", section: "CS-3A", faculty: "Dr. Reyes", room: "Room 305", color: "bg-purple-100 text-purple-800 border-purple-200" },
    "1:00 PM": { subject: "CS 202", section: "CS-2B", faculty: "Prof. Aquino", room: "Room 201", color: "bg-teal-100 text-teal-800 border-teal-200" },
    "3:00 PM": { subject: "CS 410", section: "CS-4A", faculty: "Dr. Reyes", room: "Room 401", color: "bg-indigo-100 text-indigo-800 border-indigo-200" },
  },
  "Tuesday": {
    "8:00 AM": { subject: "CS 202", section: "CS-2B", faculty: "Prof. Aquino", room: "Room 201", color: "bg-teal-100 text-teal-800 border-teal-200" },
    "10:00 AM": { subject: "CS 501", section: "CS-5A", faculty: "Dr. Reyes", room: "Room 502", color: "bg-emerald-100 text-emerald-800 border-emerald-200" },
    "2:00 PM": { subject: "CS 101", section: "CS-1B", faculty: "Prof. Aquino", room: "Room 202", color: "bg-blue-100 text-blue-800 border-blue-200" },
  },
  "Wednesday": {
    "7:00 AM": { subject: "CS 301", section: "CS-3B", faculty: "Dr. Reyes", room: "Room 305", color: "bg-purple-100 text-purple-800 border-purple-200" },
    "9:00 AM": { subject: "CS 101", section: "CS-1A", faculty: "Prof. Aquino", room: "Room 201", color: "bg-blue-100 text-blue-800 border-blue-200" },
    "1:00 PM": { subject: "CS 410", section: "CS-4A", faculty: "Dr. Reyes", room: "Room 401", color: "bg-indigo-100 text-indigo-800 border-indigo-200" },
    "3:00 PM": { subject: "CS 202", section: "CS-2A", faculty: "Prof. Aquino", room: "Room 203", color: "bg-teal-100 text-teal-800 border-teal-200" },
  },
  "Thursday": {
    "8:00 AM": { subject: "CS 501", section: "CS-5A", faculty: "Dr. Reyes", room: "Room 502", color: "bg-emerald-100 text-emerald-800 border-emerald-200" },
    "10:00 AM": { subject: "CS 301", section: "CS-3A", faculty: "Dr. Reyes", room: "Room 305", color: "bg-purple-100 text-purple-800 border-purple-200" },
    "2:00 PM": { subject: "CS 202", section: "CS-2B", faculty: "Prof. Aquino", room: "Room 201", color: "bg-teal-100 text-teal-800 border-teal-200" },
  },
  "Friday": {
    "7:00 AM": { subject: "CS 101", section: "CS-1B", faculty: "Prof. Aquino", room: "Room 202", color: "bg-blue-100 text-blue-800 border-blue-200" },
    "9:00 AM": { subject: "CS 410", section: "CS-4A", faculty: "Dr. Reyes", room: "Room 401", color: "bg-indigo-100 text-indigo-800 border-indigo-200" },
    "1:00 PM": { subject: "CS 301", section: "CS-3B", faculty: "Dr. Reyes", room: "Room 305", color: "bg-purple-100 text-purple-800 border-purple-200" },
    "4:00 PM": { subject: "CS 501", section: "CS-5A", faculty: "Dr. Reyes", room: "Room 502", color: "bg-emerald-100 text-emerald-800 border-emerald-200" },
  },
  "Saturday": {
    "8:00 AM": { subject: "CS 101", section: "CS-1A", faculty: "Prof. Aquino", room: "Room 201", color: "bg-blue-100 text-blue-800 border-blue-200" },
    "10:00 AM": { subject: "CS 202", section: "CS-2A", faculty: "Prof. Aquino", room: "Room 203", color: "bg-teal-100 text-teal-800 border-teal-200" },
  },
};

// ─── Shared: Stat card ─────────────────────────────────────────────────────────

function StatCard({ title, value, badge, iconBg, icon }: {
  title: string; value: number; badge: string; iconBg: string; icon: React.ReactNode;
}) {
  return (
    <div className="bg-card rounded-2xl border border-border p-6 flex flex-col gap-4 hover:shadow-md transition-shadow duration-200">
      <div className="flex items-start justify-between">
        <p className="text-[13px] font-medium text-muted-foreground leading-tight pr-2">{title}</p>
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${iconBg}`}>{icon}</div>
      </div>
      <p className="text-5xl font-bold text-foreground" style={{ fontVariantNumeric: "tabular-nums", letterSpacing: "-0.03em" }}>
        {value.toLocaleString()}
      </p>
      <span className="inline-block px-2.5 py-1 rounded-lg bg-muted text-[11px] font-medium text-muted-foreground w-fit">
        {badge}
      </span>
    </div>
  );
}

// ─── Shared: Page heading ──────────────────────────────────────────────────────

function PageHeading({ title }: { title: string }) {
  return (
    <h2 className="text-4xl font-bold text-foreground mb-7" style={{ letterSpacing: "-0.02em" }}>
      {title}
    </h2>
  );
}

// ─── Shared: Status badge ──────────────────────────────────────────────────────

function FacultyStatusBadge({ status }: { status: FacultyStatus }) {
  const cfg = {
    Active: { cls: "bg-emerald-50 text-emerald-700", icon: <CheckCircle size={11} /> },
    "On Leave": { cls: "bg-amber-50 text-amber-700", icon: <AlertCircle size={11} /> },
    Inactive: { cls: "bg-red-50 text-red-600", icon: <MinusCircle size={11} /> },
  }[status];
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold ${cfg.cls}`}>
      {cfg.icon}{status}
    </span>
  );
}

// ─── Dashboard page ────────────────────────────────────────────────────────────

function DashboardPage() {
  return (
    <>
      <PageHeading title="Analytics Overview" />
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        {DASHBOARD_STATS.map((s) => <StatCard key={s.title} {...s} />)}
      </div>
      <div className="bg-card rounded-2xl border border-border p-6">
        <div className="flex items-center justify-between mb-4">
          <p className="text-[15px] font-semibold text-foreground">Enrollment Completion Progress</p>
          <p className="text-4xl font-bold text-foreground" style={{ letterSpacing: "-0.03em" }}>86%</p>
        </div>
        <div className="w-full h-2 rounded-full bg-muted mb-5 overflow-hidden">
          <div className="h-full rounded-full w-[86%]" style={{ background: "var(--accent)" }} />
        </div>
        <div className="flex items-start gap-10 flex-wrap">
          {[
            { label: "Enrolled Students", val: "1,284" },
            { label: "Remaining Slots", val: "216" },
            { label: "Fully Processed", val: "1,102 / 1,500" },
          ].map((s) => (
            <div key={s.label}>
              <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-1">{s.label}</p>
              <p className="text-2xl font-bold text-foreground">{s.val}</p>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

// ─── Manage Faculty page ───────────────────────────────────────────────────────

function ManageFacultyPage() {
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState<FacultyStatus | "All">("All");
  const [showModal, setShowModal] = useState(false);

  const filtered = useMemo(() =>
    FACULTY_LIST.filter((f) => {
      const matchSearch = f.name.toLowerCase().includes(search.toLowerCase()) ||
        f.id.toLowerCase().includes(search.toLowerCase()) ||
        f.email.toLowerCase().includes(search.toLowerCase());
      const matchDept = deptFilter === "All" || f.department === deptFilter;
      const matchStatus = statusFilter === "All" || f.status === statusFilter;
      return matchSearch && matchDept && matchStatus;
    }),
    [search, deptFilter, statusFilter]
  );

  const active = FACULTY_LIST.filter((f) => f.status === "Active").length;
  const onLeave = FACULTY_LIST.filter((f) => f.status === "On Leave").length;
  const inactive = FACULTY_LIST.filter((f) => f.status === "Inactive").length;

  return (
    <>
      <PageHeading title="Manage Faculty" />

      {/* Stats */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <StatCard title="Total Faculty" value={FACULTY_LIST.length} badge="All Faculty Members" iconBg="bg-blue-100" icon={<Users size={20} className="text-blue-500" />} />
        <StatCard title="Active Faculty" value={active} badge="Currently Teaching" iconBg="bg-emerald-100" icon={<CheckCircle size={20} className="text-emerald-500" />} />
        <StatCard title="On Leave" value={onLeave} badge="Temporarily Away" iconBg="bg-amber-100" icon={<AlertCircle size={20} className="text-amber-500" />} />
        <StatCard title="Inactive" value={inactive} badge="Not Currently Active" iconBg="bg-red-100" icon={<MinusCircle size={20} className="text-red-500" />} />
      </div>

      {/* Table card */}
      <div className="bg-card rounded-2xl border border-border p-6">
        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-3 mb-5">
          <div className="relative flex-1 min-w-[180px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search faculty name, ID, email…"
              className="w-full pl-8 pr-4 py-2 text-sm bg-muted rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-accent/30 placeholder:text-muted-foreground"
            />
            {search && (
              <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                <X size={13} />
              </button>
            )}
          </div>
          <select
            value={deptFilter}
            onChange={(e) => setDeptFilter(e.target.value)}
            className="px-3 py-2 text-sm bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-accent/30"
          >
            {DEPARTMENTS.map((d) => <option key={d}>{d}</option>)}
          </select>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as FacultyStatus | "All")}
            className="px-3 py-2 text-sm bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-accent/30"
          >
            {["All", "Active", "On Leave", "Inactive"].map((s) => <option key={s}>{s}</option>)}
          </select>
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white rounded-lg"
            style={{ background: "var(--primary)" }}
          >
            <Plus size={14} /> Add Faculty
          </button>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                {["Faculty ID", "Name", "Department", "Email", "Subjects", "Units", "Status", ""].map((h) => (
                  <th key={h} className="text-left py-2.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground first:pl-0 last:pr-0">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((f, i) => (
                <tr key={f.id} className={`border-b border-border/50 hover:bg-muted/40 transition-colors ${i === filtered.length - 1 ? "border-b-0" : ""}`}>
                  <td className="py-3 px-3 pl-0">
                    <span className="text-xs font-mono text-muted-foreground" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{f.id}</span>
                  </td>
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                        style={{ background: "var(--primary)" }}>
                        {f.name.split(" ").slice(-1)[0][0]}
                      </div>
                      <span className="font-medium text-foreground whitespace-nowrap">{f.name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-3 text-sm text-muted-foreground whitespace-nowrap">{f.department}</td>
                  <td className="py-3 px-3 text-sm text-muted-foreground">{f.email}</td>
                  <td className="py-3 px-3">
                    <div className="flex flex-wrap gap-1">
                      {f.subjects.map((s) => (
                        <span key={s} className="px-2 py-0.5 rounded-md bg-muted text-[11px] font-medium text-muted-foreground">{s}</span>
                      ))}
                    </div>
                  </td>
                  <td className="py-3 px-3 text-sm text-center font-medium text-muted-foreground">{f.units}</td>
                  <td className="py-3 px-3"><FacultyStatusBadge status={f.status} /></td>
                  <td className="py-3 px-3 pr-0">
                    <button className="p-1 rounded text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
                      <MoreHorizontal size={15} />
                    </button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={8} className="py-12 text-center text-sm text-muted-foreground">No faculty found matching your filters.</td></tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
          <p className="text-xs text-muted-foreground">Showing {filtered.length} of {FACULTY_LIST.length} faculty members</p>
        </div>
      </div>

      {/* Add Faculty Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.4)" }}>
          <div className="bg-card rounded-2xl border border-border w-full max-w-md shadow-xl p-6">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-base font-semibold text-foreground">Add New Faculty</h3>
              <button onClick={() => setShowModal(false)} className="text-muted-foreground hover:text-foreground transition-colors"><X size={18} /></button>
            </div>
            <div className="flex flex-col gap-3">
              {[
                { label: "Full Name", placeholder: "Dr. Juan dela Cruz" },
                { label: "Faculty ID", placeholder: "FAC-011" },
                { label: "Email Address", placeholder: "j.delacruz@pclu.edu.ph" },
              ].map((field) => (
                <div key={field.label}>
                  <label className="block text-xs font-semibold text-muted-foreground mb-1.5">{field.label}</label>
                  <input placeholder={field.placeholder} className="w-full px-3 py-2 text-sm bg-muted border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/30 placeholder:text-muted-foreground" />
                </div>
              ))}
              <div>
                <label className="block text-xs font-semibold text-muted-foreground mb-1.5">Department</label>
                <select className="w-full px-3 py-2 text-sm bg-muted border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/30 text-foreground">
                  {DEPARTMENTS.filter((d) => d !== "All").map((d) => <option key={d}>{d}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-muted-foreground mb-1.5">Status</label>
                <select className="w-full px-3 py-2 text-sm bg-muted border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/30 text-foreground">
                  {["Active", "On Leave", "Inactive"].map((s) => <option key={s}>{s}</option>)}
                </select>
              </div>
            </div>
            <div className="flex gap-2 mt-6">
              <button onClick={() => setShowModal(false)} className="flex-1 px-4 py-2 text-sm font-medium text-muted-foreground bg-muted border border-border rounded-lg hover:bg-background transition-colors">Cancel</button>
              <button onClick={() => setShowModal(false)} className="flex-1 px-4 py-2 text-sm font-medium text-white rounded-lg transition-colors" style={{ background: "var(--primary)" }}>Add Faculty</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// ─── Manage Class List page ────────────────────────────────────────────────────

function ManageClassListPage() {
  const [search, setSearch] = useState("");
  const [subjectFilter, setSubjectFilter] = useState("All Subjects");
  const [sectionFilter, setSectionFilter] = useState("All Sections");
  const [statusFilter, setStatusFilter] = useState<StudentStatus | "All">("All");

  const filtered = useMemo(() =>
    CLASS_STUDENTS.filter((s) => {
      const matchSearch = s.name.toLowerCase().includes(search.toLowerCase()) ||
        s.studentNo.includes(search);
      const matchSubject = subjectFilter === "All Subjects" || s.subject === subjectFilter;
      const matchSection = sectionFilter === "All Sections" || s.section === sectionFilter;
      const matchStatus = statusFilter === "All" || s.status === statusFilter;
      return matchSearch && matchSubject && matchSection && matchStatus;
    }),
    [search, subjectFilter, sectionFilter, statusFilter]
  );

  const regular = CLASS_STUDENTS.filter((s) => s.status === "Regular").length;
  const irregular = CLASS_STUDENTS.filter((s) => s.status === "Irregular").length;
  const sections = new Set(CLASS_STUDENTS.map((s) => s.section)).size;

  return (
    <>
      <PageHeading title="Manage Class List" />

      {/* Stats */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <StatCard title="Total Students" value={CLASS_STUDENTS.length} badge="All Listed Students" iconBg="bg-blue-100" icon={<Users size={20} className="text-blue-500" />} />
        <StatCard title="Regular Students" value={regular} badge="On Curriculum" iconBg="bg-emerald-100" icon={<CheckCircle size={20} className="text-emerald-500" />} />
        <StatCard title="Irregular Students" value={irregular} badge="Off-Curriculum" iconBg="bg-amber-100" icon={<AlertCircle size={20} className="text-amber-500" />} />
        <StatCard title="Total Sections" value={sections} badge="Active Sections" iconBg="bg-purple-100" icon={<BookOpen size={20} className="text-purple-500" />} />
      </div>

      {/* Table card */}
      <div className="bg-card rounded-2xl border border-border p-6">
        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-3 mb-5">
          <div className="relative flex-1 min-w-[180px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search student name or number…"
              className="w-full pl-8 pr-4 py-2 text-sm bg-muted rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-accent/30 placeholder:text-muted-foreground"
            />
            {search && (
              <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"><X size={13} /></button>
            )}
          </div>
          <select value={subjectFilter} onChange={(e) => setSubjectFilter(e.target.value)} className="px-3 py-2 text-sm bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-accent/30">
            {SUBJECT_OPTIONS.map((s) => <option key={s}>{s}</option>)}
          </select>
          <select value={sectionFilter} onChange={(e) => setSectionFilter(e.target.value)} className="px-3 py-2 text-sm bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-accent/30">
            {SECTION_OPTIONS.map((s) => <option key={s}>{s}</option>)}
          </select>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as StudentStatus | "All")} className="px-3 py-2 text-sm bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-accent/30">
            {["All", "Regular", "Irregular"].map((s) => <option key={s}>{s}</option>)}
          </select>
          <button className="flex items-center gap-1.5 px-3 py-2 text-sm text-muted-foreground bg-muted border border-border rounded-lg hover:bg-background transition-colors">
            <Filter size={13} /> Export
          </button>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                {["Student No.", "Name", "Course", "Year Level", "Section", "Subject", "Status", ""].map((h) => (
                  <th key={h} className="text-left py-2.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground first:pl-0 last:pr-0">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((s, i) => (
                <tr key={s.studentNo} className={`border-b border-border/50 hover:bg-muted/40 transition-colors ${i === filtered.length - 1 ? "border-b-0" : ""}`}>
                  <td className="py-3 px-3 pl-0">
                    <span className="text-xs font-mono text-muted-foreground" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{s.studentNo}</span>
                  </td>
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-bold text-white flex-shrink-0"
                        style={{ background: "var(--primary)" }}>
                        {s.name[0]}
                      </div>
                      <span className="font-medium text-foreground whitespace-nowrap">{s.name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-3 text-sm text-muted-foreground">{s.course}</td>
                  <td className="py-3 px-3 text-sm text-muted-foreground whitespace-nowrap">{s.yearLevel}</td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded-md bg-muted text-[11px] font-semibold text-muted-foreground">{s.section}</span>
                  </td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 text-[11px] font-semibold">{s.subject}</span>
                  </td>
                  <td className="py-3 px-3">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold ${s.status === "Regular" ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`}>
                      {s.status === "Regular" ? <CheckCircle size={11} /> : <AlertCircle size={11} />}
                      {s.status}
                    </span>
                  </td>
                  <td className="py-3 px-3 pr-0">
                    <button className="p-1 rounded text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"><MoreHorizontal size={15} /></button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={8} className="py-12 text-center text-sm text-muted-foreground">No students found matching your filters.</td></tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
          <p className="text-xs text-muted-foreground">Showing {filtered.length} of {CLASS_STUDENTS.length} students</p>
        </div>
      </div>
    </>
  );
}

// ─── View Schedule page ────────────────────────────────────────────────────────

function ViewSchedulePage() {
  const [selectedDay, setSelectedDay] = useState<string>("All");
  const [selectedFaculty, setSelectedFaculty] = useState<string>("All");

  const facultyOptions = ["All", "Dr. Reyes", "Prof. Aquino"];

  const visibleDays = selectedDay === "All" ? DAYS : [selectedDay];

  const totalBlocks = Object.values(SCHEDULE).reduce((acc, day) =>
    acc + Object.values(day).filter(Boolean).length, 0);

  const scheduledSubjects = new Set(
    Object.values(SCHEDULE).flatMap((day) =>
      Object.values(day).filter(Boolean).map((b) => b!.subject)
    )
  ).size;

  return (
    <>
      <PageHeading title="View Schedule" />

      {/* Stats */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <StatCard title="Total Scheduled Blocks" value={totalBlocks} badge="All Days Combined" iconBg="bg-blue-100" icon={<CalendarDays size={20} className="text-blue-500" />} />
        <StatCard title="Unique Subjects" value={scheduledSubjects} badge="Active Subjects" iconBg="bg-purple-100" icon={<BookOpen size={20} className="text-purple-500" />} />
        <StatCard title="Active Faculty" value={2} badge="With Assigned Loads" iconBg="bg-emerald-100" icon={<Users size={20} className="text-emerald-500" />} />
        <StatCard title="Time Slots Used" value={TIME_SLOTS.length} badge="Available Time Slots" iconBg="bg-amber-100" icon={<Clock size={20} className="text-amber-500" />} />
      </div>

      {/* Schedule card */}
      <div className="bg-card rounded-2xl border border-border p-6">
        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 mb-5">
          <div className="flex items-center gap-1.5 text-sm font-medium text-muted-foreground">
            <Filter size={14} /> Filter:
          </div>
          {/* Day filter */}
          <div className="flex items-center gap-1 bg-muted rounded-lg p-1 flex-wrap">
            {["All", ...DAYS].map((d) => (
              <button
                key={d}
                onClick={() => setSelectedDay(d)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors ${selectedDay === d ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
              >
                {d === "All" ? "All Days" : d.slice(0, 3)}
              </button>
            ))}
          </div>
          {/* Faculty filter */}
          <select
            value={selectedFaculty}
            onChange={(e) => setSelectedFaculty(e.target.value)}
            className="px-3 py-2 text-sm bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-accent/30"
          >
            {facultyOptions.map((f) => <option key={f}>{f === "All" ? "All Faculty" : f}</option>)}
          </select>
        </div>

        {/* Grid */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs border-collapse" style={{ minWidth: 600 }}>
            <thead>
              <tr>
                <th className="w-20 py-2 px-3 text-left text-[11px] font-semibold uppercase tracking-wider text-muted-foreground border-b border-r border-border bg-muted/30">
                  Time
                </th>
                {visibleDays.map((day) => (
                  <th key={day} className="py-2 px-3 text-center text-[11px] font-semibold uppercase tracking-wider text-muted-foreground border-b border-r border-border bg-muted/30 last:border-r-0">
                    {day}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {TIME_SLOTS.map((slot, ri) => (
                <tr key={slot} className={ri % 2 === 0 ? "" : "bg-muted/10"}>
                  <td className="py-2 px-3 text-[11px] font-mono font-medium text-muted-foreground border-r border-b border-border whitespace-nowrap" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                    {slot}
                  </td>
                  {visibleDays.map((day) => {
                    const block = SCHEDULE[day]?.[slot];
                    const show = block && (selectedFaculty === "All" || block.faculty === selectedFaculty);
                    return (
                      <td key={day} className="py-1.5 px-2 border-r border-b border-border last:border-r-0 align-top" style={{ minWidth: 110 }}>
                        {show ? (
                          <div className={`rounded-lg border px-2.5 py-2 flex flex-col gap-0.5 ${block.color}`}>
                            <span className="font-bold text-[12px] leading-tight">{block.subject}</span>
                            <span className="text-[10px] font-medium opacity-75">{block.section}</span>
                            <span className="text-[10px] opacity-60 truncate">{block.faculty}</span>
                            <span className="text-[10px] opacity-60">{block.room}</span>
                          </div>
                        ) : null}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-3 mt-4 pt-4 border-t border-border">
          <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Legend:</span>
          {[
            { label: "CS 101", color: "bg-blue-100 border-blue-200 text-blue-800" },
            { label: "CS 202", color: "bg-teal-100 border-teal-200 text-teal-800" },
            { label: "CS 301", color: "bg-purple-100 border-purple-200 text-purple-800" },
            { label: "CS 410", color: "bg-indigo-100 border-indigo-200 text-indigo-800" },
            { label: "CS 501", color: "bg-emerald-100 border-emerald-200 text-emerald-800" },
          ].map((l) => (
            <span key={l.label} className={`inline-flex items-center px-2.5 py-1 rounded-lg border text-[11px] font-semibold ${l.color}`}>
              {l.label}
            </span>
          ))}
        </div>
      </div>
    </>
  );
}

// ─── Main App ──────────────────────────────────────────────────────────────────

export default function App() {
  const [activePage, setActivePage] = useState<Page>("dashboard");
  const [collapsed, setCollapsed] = useState(false);

  const pageTitle = NAV_ITEMS.find((n) => n.key === activePage)?.label ?? "Dashboard";

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* ════════ SIDEBAR ════════ */}
      <aside
        className="relative flex-shrink-0 flex flex-col h-full transition-all duration-300"
        style={{ width: collapsed ? 64 : 240, background: "var(--sidebar)" }}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-5">
          <div className="flex-shrink-0 w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "var(--accent)" }}>
            <GraduationCap size={18} className="text-white" />
          </div>
          {!collapsed && (
            <div className="overflow-hidden leading-tight">
              <p className="text-white font-bold text-sm tracking-tight">PCLU</p>
              <p className="text-white font-semibold text-[13px] tracking-tight">Registrar Portal</p>
            </div>
          )}
        </div>

        {/* User profile */}
        {!collapsed && (
          <div className="mx-3 mb-4 flex items-center gap-2.5 px-3 py-2.5 rounded-xl cursor-pointer" style={{ background: "rgba(255,255,255,0.07)" }}>
            <div className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold text-white" style={{ background: "var(--accent)" }}>R</div>
            <div className="flex-1 min-w-0 leading-tight">
              <p className="text-white text-xs font-semibold truncate">Registrar Office</p>
              <p className="text-[11px] font-medium truncate" style={{ color: "var(--accent)" }}>registrar</p>
            </div>
            <ChevronRight size={14} className="text-white/40 flex-shrink-0" />
          </div>
        )}

        {/* Nav label */}
        {!collapsed && (
          <p className="px-4 text-[10px] font-semibold uppercase tracking-widest mb-2" style={{ color: "rgba(255,255,255,0.3)" }}>
            Navigation
          </p>
        )}

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto px-2 flex flex-col gap-0.5">
          {NAV_ITEMS.map((item) => {
            const isActive = activePage === item.key;
            return (
              <button
                key={item.key}
                onClick={() => setActivePage(item.key)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-[13px] font-medium transition-all duration-150 ${
                  isActive ? "text-white" : "text-white/55 hover:text-white/85 hover:bg-white/5"
                }`}
                style={isActive ? { background: "rgba(255,255,255,0.1)" } : {}}
              >
                <span className="flex-shrink-0" style={isActive ? { color: "var(--accent)" } : {}}>
                  {item.icon}
                </span>
                {!collapsed && <span className="flex-1 text-left truncate">{item.label}</span>}
              </button>
            );
          })}
        </nav>

        {/* Disconnect */}
        <div className="px-2 py-4 border-t" style={{ borderColor: "rgba(255,255,255,0.07)" }}>
          <button className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-white/40 hover:text-white/70 hover:bg-white/5 transition-colors text-[13px]">
            <LogOut size={16} className="flex-shrink-0" />
            {!collapsed && <span>Disconnect Session</span>}
          </button>
        </div>

        {/* Collapse toggle */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="absolute -right-3.5 top-1/2 -translate-y-1/2 z-10 w-7 h-7 rounded-full flex items-center justify-center shadow-md border"
          style={{ background: "var(--sidebar)", borderColor: "rgba(255,255,255,0.12)", color: "rgba(255,255,255,0.6)" }}
        >
          {collapsed ? <ChevronRight size={13} /> : <ChevronLeft size={13} />}
        </button>
      </aside>

      {/* ════════ MAIN ════════ */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="flex-shrink-0 h-14 bg-card border-b border-border flex items-center px-6 gap-4">
          <h1 className="flex-1 text-[15px] font-semibold text-foreground">PCLU Academic Control Workspace</h1>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-border bg-white text-[12px] font-medium text-foreground">
            <span className="w-2 h-2 rounded-full bg-emerald-500 flex-shrink-0" />
            A.Y. 2026–2027
          </div>
          <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold text-white cursor-pointer flex-shrink-0" style={{ background: "var(--accent)" }}>
            R
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-8">
          {activePage === "dashboard" && <DashboardPage />}
          {activePage === "manage-faculty" && <ManageFacultyPage />}
          {activePage === "manage-classlist" && <ManageClassListPage />}
          {activePage === "view-schedule" && <ViewSchedulePage />}
        </main>
      </div>
    </div>
  );
}
