
  # Registrar User Dashboard

  This is a code bundle for Registrar User Dashboard. The original project is available at https://www.figma.com/design/tw0pXPYOwQol4mt0cbeibi/Registrar-User-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  