
  # Redesign Sidebar with Hamburger

  This is a code bundle for Redesign Sidebar with Hamburger. The original project is available at https://www.figma.com/design/o237rkbWhFdmu23H7XuMzn/Redesign-Sidebar-with-Hamburger.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  