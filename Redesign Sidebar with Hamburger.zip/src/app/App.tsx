import { useState } from "react";
import {
  LayoutDashboard,
  CalendarDays,
  ClipboardList,
  Users,
  DoorOpen,
  Trash2,
  History,
  LogOut,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard View", id: "dashboard" },
  { icon: CalendarDays, label: "Schedule Plotter", id: "plotter" },
  { icon: ClipboardList, label: "Manage Schedules", id: "schedules" },
  { icon: Users, label: "Manage Teachers", id: "teachers" },
  { icon: DoorOpen, label: "Manage Rooms", id: "rooms" },
  { icon: Trash2, label: "Recently Deleted", id: "deleted" },
  { icon: History, label: "Audit Logs", id: "audit" },
];

export default function App() {
  const [active, setActive] = useState("plotter");
  const [open, setOpen] = useState(true);

  return (
    <div className="flex h-screen bg-[#0f1117] font-['Inter',sans-serif] overflow-hidden">
      {/* Sidebar */}
      <aside
        className="relative flex flex-col transition-all duration-300 ease-in-out shrink-0"
        style={{ width: open ? 260 : 72 }}
      >
        {/* Gradient background */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#1a1d2e] to-[#12141f] border-r border-white/[0.06]" />

        {/* Glow accent */}
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#f5c842]/40 to-transparent" />

        <div className="relative flex flex-col h-full z-10">

          {/* Header */}
          <div className="flex items-center gap-3 px-4 pt-5 pb-4 min-h-[72px]">
            {/* Logo icon */}
            <div className="shrink-0 w-10 h-10 rounded-xl bg-gradient-to-br from-[#f5c842] to-[#e0a800] flex items-center justify-center shadow-lg shadow-[#f5c842]/20">
              <CalendarDays size={18} className="text-[#1a1d2e]" />
            </div>
            {open && (
              <div className="flex flex-col overflow-hidden">
                <span className="text-[10px] font-semibold tracking-widest text-[#f5c842]/70 uppercase leading-none">PCLU</span>
                <span className="text-[15px] font-bold text-white leading-tight truncate">OptimaSched</span>
              </div>
            )}
          </div>

          {/* Arrow toggle — vertically centered */}
          <button
            onClick={() => setOpen(!open)}
            className="absolute -right-3.5 top-1/2 -translate-y-1/2 z-20 w-7 h-7 rounded-full bg-[#1e2235] border border-white/10 flex items-center justify-center text-white/50 hover:text-white hover:border-[#f5c842]/40 hover:bg-[#252840] transition-all shadow-md"
          >
            {open ? <ChevronLeft size={14} /> : <ChevronRight size={14} />}
          </button>

          {/* Divider */}
          <div className="mx-4 h-px bg-white/[0.06] mb-4" />

          {/* User card */}
          <div className={`mx-3 mb-5 rounded-xl transition-all duration-300 ${open ? "bg-white/[0.05] border border-white/[0.07] p-3" : "flex justify-center"}`}>
            <div className="flex items-center gap-3">
              <div className="shrink-0 w-9 h-9 rounded-full bg-gradient-to-br from-[#f5c842] to-[#e0a800] flex items-center justify-center text-[#1a1d2e] text-sm font-bold shadow-md">
                A
              </div>
              {open && (
                <div className="flex flex-col overflow-hidden">
                  <span className="text-sm font-semibold text-white/90 truncate leading-tight">Aris Admin</span>
                  <span className="text-[11px] text-[#f5c842] font-medium leading-tight">administrator</span>
                </div>
              )}
            </div>
            {open && (
              <ChevronRight size={14} className="ml-auto text-white/20 self-center shrink-0" />
            )}
          </div>

          {/* Nav label */}
          {open && (
            <p className="px-5 mb-2 text-[10px] font-bold tracking-[0.15em] text-white/25 uppercase">Navigation</p>
          )}

          {/* Nav items */}
          <nav className="flex flex-col gap-0.5 px-2 flex-1">
            {navItems.map(({ icon: Icon, label, id }) => {
              const isActive = active === id;
              return (
                <button
                  key={id}
                  onClick={() => setActive(id)}
                  className={`group relative flex items-center gap-3 rounded-xl transition-all duration-200 text-left
                    ${open ? "px-3 py-2.5" : "justify-center px-0 py-2.5 w-full"}
                    ${isActive
                      ? "bg-[#f5c842]/10 text-[#f5c842]"
                      : "text-white/45 hover:text-white/80 hover:bg-white/[0.04]"
                    }`}
                >
                  {/* Active left bar */}
                  {isActive && (
                    <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 rounded-r bg-[#f5c842]" />
                  )}

                  <Icon
                    size={17}
                    className={`shrink-0 transition-colors ${isActive ? "text-[#f5c842]" : "text-white/35 group-hover:text-white/65"}`}
                  />

                  {open && (
                    <span className={`text-[13.5px] font-medium truncate ${isActive ? "text-white font-semibold" : ""}`}>
                      {label}
                    </span>
                  )}

                  {/* Tooltip when collapsed */}
                  {!open && (
                    <span className="absolute left-full ml-3 px-2.5 py-1 rounded-lg bg-[#252840] text-white text-xs font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity shadow-xl border border-white/10 z-50">
                      {label}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Bottom divider + logout */}
          <div className="px-4 pb-5 pt-3">
            <div className="h-px bg-white/[0.06] mb-4" />
            <button
              className={`group flex items-center gap-3 rounded-xl text-white/30 hover:text-[#ff6b6b] hover:bg-[#ff6b6b]/[0.07] transition-all duration-200 w-full
                ${open ? "px-3 py-2.5" : "justify-center py-2.5"}`}
            >
              <LogOut size={16} className="shrink-0" />
              {open && <span className="text-[13px] font-medium">Disconnect Session</span>}
              {!open && (
                <span className="absolute left-full ml-3 px-2.5 py-1 rounded-lg bg-[#252840] text-white text-xs font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity shadow-xl border border-white/10 z-50">
                  Disconnect Session
                </span>
              )}
            </button>
          </div>
        </div>
      </aside>

      {/* Main content placeholder */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        

        {/* Body */}
        
      </main>
    </div>
  );
}
