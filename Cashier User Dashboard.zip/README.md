
  # Cashier User Dashboard

  This is a code bundle for Cashier User Dashboard. The original project is available at https://www.figma.com/design/mSYyTudqvXxRvvWdWSomEz/Cashier-User-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  