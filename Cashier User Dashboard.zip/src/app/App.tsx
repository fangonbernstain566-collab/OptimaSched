import { useState } from "react";
import {
  LayoutDashboard,
  FileText,
  ChevronRight,
  LogOut,
  ChevronLeft,
  Banknote,
  Clock,
  CheckCircle,
  AlertCircle,
  CreditCard,
  Users,
  Search,
  Download,
  Plus,
  TrendingUp,
  TrendingDown,
  BarChart2,
  Calendar,
  X,
  Check,
  GraduationCap,
  BookOpen,
  Mail,
  Phone,
  Edit2,
  Trash2,
  BookMarked,
  UserCheck,
  ChevronUp,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, Legend,
} from "recharts";

// ─── Types ────────────────────────────────────────────────────────────────────

interface Faculty {
  id: string;
  name: string;
  department: string;
  email: string;
  phone: string;
  subjects: string[];
  status: "Active" | "On Leave" | "Inactive";
  yearsExp: number;
}

interface ClassItem {
  id: string;
  code: string;
  name: string;
  instructor: string;
  department: string;
  units: number;
  enrolled: number;
  capacity: number;
  schedule: string;
  room: string;
  students: string[];
}

// ─── Shared Data ──────────────────────────────────────────────────────────────

const allTransactions = [
  { id: "TXN-0041", student: "Maria Santos", studentId: "2023-0001", amount: 12500, type: "Tuition Fee", status: "Confirmed", time: "9:14 AM", date: "2026-07-07", method: "Cash" },
  { id: "TXN-0040", student: "Juan dela Cruz", studentId: "2023-0002", amount: 8750, type: "Miscellaneous", status: "Pending", time: "9:02 AM", date: "2026-07-07", method: "GCash" },
  { id: "TXN-0039", student: "Ana Reyes", studentId: "2022-0015", amount: 5000, type: "Partial Payment", status: "Confirmed", time: "8:48 AM", date: "2026-07-07", method: "Cash" },
  { id: "TXN-0038", student: "Carlo Mendoza", studentId: "2024-0008", amount: 15000, type: "Tuition Fee", status: "Confirmed", time: "8:31 AM", date: "2026-07-07", method: "Bank Transfer" },
  { id: "TXN-0037", student: "Liza Torres", studentId: "2023-0034", amount: 3200, type: "Lab Fee", status: "Pending", time: "8:15 AM", date: "2026-07-07", method: "GCash" },
  { id: "TXN-0036", student: "Ramon Villanueva", studentId: "2021-0009", amount: 18000, type: "Tuition Fee", status: "Confirmed", time: "7:55 AM", date: "2026-07-07", method: "Cash" },
];

const initialFaculty: Faculty[] = [
  { id: "FAC-001", name: "Dr. Elena Cruz", department: "Computer Science", email: "e.cruz@pclu.edu", phone: "09171234567", subjects: ["Data Structures", "Algorithms"], status: "Active", yearsExp: 12 },
  { id: "FAC-002", name: "Prof. Ricardo Santos", department: "Information Technology", email: "r.santos@pclu.edu", phone: "09281234567", subjects: ["Web Development", "Database Systems"], status: "Active", yearsExp: 8 },
  { id: "FAC-003", name: "Dr. Maribel Reyes", department: "Business Administration", email: "m.reyes@pclu.edu", phone: "09391234567", subjects: ["Business Math", "Accounting Fundamentals"], status: "Active", yearsExp: 15 },
  { id: "FAC-004", name: "Prof. Dante Villanueva", department: "Education", email: "d.villanueva@pclu.edu", phone: "09171239876", subjects: ["Principles of Teaching", "Curriculum Development"], status: "On Leave", yearsExp: 10 },
  { id: "FAC-005", name: "Dr. Carmela Gomez", department: "Accountancy", email: "c.gomez@pclu.edu", phone: "09281239876", subjects: ["Financial Accounting", "Auditing"], status: "Active", yearsExp: 18 },
  { id: "FAC-006", name: "Prof. Leo Bautista", department: "Computer Science", email: "l.bautista@pclu.edu", phone: "09391239876", subjects: ["Operating Systems", "Computer Networks"], status: "Inactive", yearsExp: 5 },
];

const initialClasses: ClassItem[] = [
  { id: "CLS-001", code: "CS301", name: "Data Structures and Algorithms", instructor: "Dr. Elena Cruz", department: "BSCS", units: 3, enrolled: 32, capacity: 40, schedule: "MWF 7:30–8:30 AM", room: "Room 201", students: ["Maria Santos", "Carlo Mendoza", "Mark Aquino", "Diego Cruz"] },
  { id: "CLS-002", code: "IT201", name: "Web Development", instructor: "Prof. Ricardo Santos", department: "BSIT", units: 3, enrolled: 28, capacity: 35, schedule: "TTh 9:00–10:30 AM", room: "Room 105", students: ["Juan dela Cruz", "Carla Bautista"] },
  { id: "CLS-003", code: "ACC201", name: "Financial Accounting", instructor: "Dr. Carmela Gomez", department: "BSA", units: 3, enrolled: 35, capacity: 40, schedule: "MWF 10:30–11:30 AM", room: "Room 310", students: ["Ana Reyes", "Sofia Ramos"] },
  { id: "CLS-004", code: "BA101", name: "Business Mathematics", instructor: "Dr. Maribel Reyes", department: "BSBA", units: 3, enrolled: 22, capacity: 35, schedule: "TTh 1:00–2:30 PM", room: "Room 208", students: ["Ramon Villanueva", "Nico Fernandez"] },
  { id: "CLS-005", code: "ED301", name: "Principles of Teaching", instructor: "Prof. Dante Villanueva", department: "BSED", units: 3, enrolled: 18, capacity: 30, schedule: "MWF 2:30–3:30 PM", room: "Room 412", students: ["Liza Torres", "Patricia Gomez"] },
  { id: "CLS-006", code: "CS401", name: "Computer Networks", instructor: "Prof. Leo Bautista", department: "BSCS", units: 3, enrolled: 25, capacity: 35, schedule: "TTh 3:00–4:30 PM", room: "Room 203", students: ["Maria Santos", "Diego Cruz"] },
  { id: "CLS-007", code: "IT301", name: "Database Systems", instructor: "Prof. Ricardo Santos", department: "BSIT", units: 3, enrolled: 30, capacity: 35, schedule: "MWF 8:30–9:30 AM", room: "Room 106", students: ["Juan dela Cruz", "Carla Bautista"] },
  { id: "CLS-008", code: "ACC301", name: "Auditing Theory", instructor: "Dr. Carmela Gomez", department: "BSA", units: 3, enrolled: 20, capacity: 30, schedule: "TTh 10:30 AM–12:00 PM", room: "Room 311", students: ["Ana Reyes", "Sofia Ramos"] },
];

const weeklyData = [
  { day: "Mon", amount: 35000 },
  { day: "Tue", amount: 52000 },
  { day: "Wed", amount: 41000 },
  { day: "Thu", amount: 67000 },
  { day: "Fri", amount: 48200 },
];

const monthlyData = [
  { month: "Jan", amount: 420000 },
  { month: "Feb", amount: 380000 },
  { month: "Mar", amount: 510000 },
  { month: "Apr", amount: 460000 },
  { month: "May", amount: 590000 },
  { month: "Jun", amount: 530000 },
  { month: "Jul", amount: 243200 },
];

const paymentTypeData = [
  { name: "Tuition Fee", value: 58, color: "#1e2d6e" },
  { name: "Miscellaneous", value: 20, color: "#c9a227" },
  { name: "Lab Fee", value: 10, color: "#6366f1" },
  { name: "Enrollment Fee", value: 8, color: "#ec4899" },
  { name: "Other", value: 4, color: "#10b981" },
];

const paymentMethodData = [
  { name: "Cash", value: 55, color: "#1e2d6e" },
  { name: "GCash", value: 28, color: "#c9a227" },
  { name: "Bank Transfer", value: 17, color: "#6366f1" },
];

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
const TIME_SLOTS = [
  "7:30 AM", "8:30 AM", "9:30 AM", "10:30 AM", "11:30 AM",
  "12:30 PM", "1:30 PM", "2:30 PM", "3:30 PM", "4:30 PM",
];

// colours per class for the schedule grid
const CLASS_COLORS = [
  { bg: "#dbeafe", text: "#1e40af", border: "#93c5fd" },
  { bg: "#fce7f3", text: "#9d174d", border: "#f9a8d4" },
  { bg: "#dcfce7", text: "#166534", border: "#86efac" },
  { bg: "#fef3c7", text: "#92400e", border: "#fcd34d" },
  { bg: "#ede9fe", text: "#5b21b6", border: "#c4b5fd" },
  { bg: "#ffedd5", text: "#9a3412", border: "#fdba74" },
  { bg: "#f0fdf4", text: "#14532d", border: "#6ee7b7" },
  { bg: "#fdf2f8", text: "#701a75", border: "#e879f9" },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

const fmt = (n: number) => "₱ " + n.toLocaleString("en-PH");

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, { bg: string; color: string }> = {
    Confirmed: { bg: "#dcfce7", color: "#166534" },
    Pending: { bg: "#fef9c3", color: "#854d0e" },
    Active: { bg: "#dcfce7", color: "#166534" },
    "On Leave": { bg: "#fef9c3", color: "#854d0e" },
    Inactive: { bg: "#fee2e2", color: "#991b1b" },
    Paid: { bg: "#dcfce7", color: "#166534" },
    Partial: { bg: "#dbeafe", color: "#1e40af" },
    Unpaid: { bg: "#fee2e2", color: "#991b1b" },
  };
  const s = styles[status] ?? { bg: "#f3f4f6", color: "#374151" };
  return (
    <span className="inline-block px-2.5 py-0.5 rounded-full text-[11px] font-semibold" style={s}>
      {status}
    </span>
  );
}

function Avatar({ name, size = 36 }: { name: string; size?: number }) {
  const palette = ["#162347", "#c9a227", "#6366f1", "#ec4899", "#10b981", "#f59e0b"];
  const idx = name.charCodeAt(0) % palette.length;
  return (
    <div
      className="flex items-center justify-center rounded-full text-white font-bold flex-shrink-0"
      style={{ width: size, height: size, background: palette[idx], fontSize: size * 0.38 }}
    >
      {name.split(" ").map(w => w[0]).slice(0, 2).join("")}
    </div>
  );
}

// ─── Modal: Add Payment ───────────────────────────────────────────────────────

function AddPaymentModal({ onClose }: { onClose: () => void }) {
  const [form, setForm] = useState({ student: "", type: "Tuition Fee", amount: "", method: "Cash" });
  const [saved, setSaved] = useState(false);
  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaved(true);
    setTimeout(onClose, 1200);
  }
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 p-6">
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-lg font-semibold text-foreground">New Payment Entry</h3>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-muted transition-colors"><X size={16} /></button>
        </div>
        {saved ? (
          <div className="flex flex-col items-center gap-3 py-8">
            <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
              <Check size={24} className="text-green-600" />
            </div>
            <p className="font-semibold text-foreground">Payment Recorded!</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div>
              <label className="text-[13px] font-medium text-muted-foreground mb-1 block">Student Name / ID</label>
              <input className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-input-background outline-none focus:ring-2 focus:ring-ring/30" placeholder="e.g. Maria Santos or 2023-0001" value={form.student} onChange={e => setForm({ ...form, student: e.target.value })} required />
            </div>
            <div>
              <label className="text-[13px] font-medium text-muted-foreground mb-1 block">Payment Type</label>
              <select className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-input-background outline-none" value={form.type} onChange={e => setForm({ ...form, type: e.target.value })}>
                {["Tuition Fee", "Miscellaneous", "Lab Fee", "Enrollment Fee", "Partial Payment", "ID Fee"].map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[13px] font-medium text-muted-foreground mb-1 block">Amount (₱)</label>
              <input type="number" className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-input-background outline-none focus:ring-2 focus:ring-ring/30" placeholder="0.00" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} required />
            </div>
            <div>
              <label className="text-[13px] font-medium text-muted-foreground mb-1 block">Payment Method</label>
              <select className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-input-background outline-none" value={form.method} onChange={e => setForm({ ...form, method: e.target.value })}>
                {["Cash", "GCash", "Bank Transfer"].map(m => <option key={m}>{m}</option>)}
              </select>
            </div>
            <div className="flex gap-3 mt-1">
              <button type="button" onClick={onClose} className="flex-1 py-2 rounded-lg border border-border text-sm font-medium text-muted-foreground hover:bg-muted transition-colors">Cancel</button>
              <button type="submit" className="flex-1 py-2 rounded-lg text-sm font-semibold text-white transition-colors" style={{ background: "#162347" }}>Save Payment</button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

// ─── Page: Dashboard ──────────────────────────────────────────────────────────

function DashboardPage({ onNewPayment }: { onNewPayment: () => void }) {
  const statCards = [
    { label: "Total Payments", value: "₱ 48,200", sub: "Today's Collections", icon: Banknote, iconBg: "bg-blue-100", iconColor: "text-blue-600" },
    { label: "Pending Transactions", value: "14", sub: "Awaiting Confirmation", icon: Clock, iconBg: "bg-purple-100", iconColor: "text-purple-600" },
    { label: "Confirmed Payments", value: "37", sub: "Verified Today", icon: CheckCircle, iconBg: "bg-pink-100", iconColor: "text-pink-600" },
    { label: "Outstanding Balances", value: "9", sub: "Students w/ Due", icon: AlertCircle, iconBg: "bg-orange-100", iconColor: "text-orange-500" },
  ];
  return (
    <main className="flex-1 overflow-y-auto px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-[28px] font-semibold text-foreground">Analytics Overview</h1>
        <button onClick={onNewPayment} className="flex items-center gap-2 px-4 py-2 rounded-lg text-white text-sm font-semibold transition-colors hover:opacity-90" style={{ background: "#c9a227" }}>
          <Plus size={15} /> New Payment
        </button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        {statCards.map(card => (
          <div key={card.label} className="bg-card rounded-xl border border-border p-5 flex flex-col gap-3">
            <div className="flex items-start justify-between">
              <p className="text-[13px] font-medium text-muted-foreground leading-snug max-w-[70%]">{card.label}</p>
              <div className={`flex items-center justify-center rounded-full ${card.iconBg} flex-shrink-0`} style={{ width: 40, height: 40 }}>
                <card.icon size={20} className={card.iconColor} />
              </div>
            </div>
            <p className="text-[32px] font-semibold text-foreground leading-none">{card.value}</p>
            <span className="inline-block text-[11px] font-medium text-muted-foreground bg-muted px-2 py-0.5 rounded-full w-fit">{card.sub}</span>
          </div>
        ))}
      </div>
      <div className="bg-card rounded-xl border border-border p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-[17px] font-semibold text-foreground">Daily Collection Progress</h3>
          <span className="text-[28px] font-semibold text-foreground">72%</span>
        </div>
        <div className="w-full h-2 rounded-full bg-muted overflow-hidden mb-5">
          <div className="h-full rounded-full" style={{ width: "72%", background: "#c9a227" }} />
        </div>
        <div className="grid grid-cols-3 gap-4">
          {[{ label: "Collected Today", value: "₱ 48,200" }, { label: "Target Amount", value: "₱ 67,000" }, { label: "Transactions", value: "37 / 51" }].map(item => (
            <div key={item.label}>
              <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-1">{item.label}</p>
              <p className="text-[18px] font-semibold text-foreground">{item.value}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-[15px] font-semibold text-foreground mb-4">Weekly Collections</h3>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={weeklyData} barSize={32}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="day" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={v => `₱${(v / 1000).toFixed(0)}k`} />
              <Tooltip formatter={(v: number) => fmt(v)} />
              <Bar dataKey="amount" fill="#162347" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-[15px] font-semibold text-foreground mb-4">Payment Type Breakdown</h3>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={paymentTypeData} dataKey="value" cx="50%" cy="50%" outerRadius={70} innerRadius={40}>
                {paymentTypeData.map(entry => <Cell key={entry.name} fill={entry.color} />)}
              </Pie>
              <Legend iconType="circle" iconSize={8} formatter={v => <span style={{ fontSize: 12 }}>{v}</span>} />
              <Tooltip formatter={(v: number) => `${v}%`} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="bg-card rounded-xl border border-border p-6">
        <h3 className="text-[17px] font-semibold text-foreground mb-4">Recent Transactions</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-border">
                {["Transaction ID", "Student", "Amount", "Type", "Status", "Time"].map(col => (
                  <th key={col} className="text-left pb-3 pr-4 font-semibold text-muted-foreground uppercase tracking-wide text-[10px]">{col}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {allTransactions.map((tx, i) => (
                <tr key={tx.id} className={i < allTransactions.length - 1 ? "border-b border-border" : ""}>
                  <td className="py-3 pr-4 font-medium text-foreground">{tx.id}</td>
                  <td className="py-3 pr-4 text-foreground">{tx.student}</td>
                  <td className="py-3 pr-4 font-semibold text-foreground">{fmt(tx.amount)}</td>
                  <td className="py-3 pr-4 text-muted-foreground">{tx.type}</td>
                  <td className="py-3 pr-4"><StatusBadge status={tx.status} /></td>
                  <td className="py-3 text-muted-foreground">{tx.time}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </main>
  );
}

// ─── Page: Reports ────────────────────────────────────────────────────────────

function ReportsPage() {
  const [period, setPeriod] = useState<"weekly" | "monthly">("monthly");
  return (
    <main className="flex-1 overflow-y-auto px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-[28px] font-semibold text-foreground">Reports</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Financial summaries and collection analytics</p>
        </div>
        <div className="flex gap-2">
          <div className="flex rounded-lg border border-border overflow-hidden">
            {(["weekly", "monthly"] as const).map(p => (
              <button key={p} onClick={() => setPeriod(p)} className="px-4 py-2 text-sm font-medium capitalize transition-colors" style={period === p ? { background: "#162347", color: "#fff" } : { background: "white", color: "#6b7280" }}>{p}</button>
            ))}
          </div>
          <button className="flex items-center gap-2 px-3 py-2 rounded-lg border border-border text-sm font-medium text-muted-foreground hover:bg-muted transition-colors">
            <Download size={14} /> Export PDF
          </button>
        </div>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          { label: "Total Collected (Jul)", value: "₱ 243,200", change: "+12.4%", up: true, icon: TrendingUp },
          { label: "Avg. Daily Collection", value: "₱ 48,640", change: "+5.2%", up: true, icon: BarChart2 },
          { label: "Pending Collections", value: "₱ 89,750", change: "-3.1%", up: false, icon: TrendingDown },
          { label: "Students Fully Paid", value: "5 / 12", change: "41.7%", up: true, icon: Users },
        ].map(k => (
          <div key={k.label} className="bg-card rounded-xl border border-border p-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">{k.label}</p>
              <k.icon size={15} className={k.up ? "text-green-500" : "text-red-500"} />
            </div>
            <p className="text-[20px] font-semibold text-foreground leading-tight">{k.value}</p>
            <p className={`text-[11px] font-medium mt-1 ${k.up ? "text-green-600" : "text-red-500"}`}>{k.change} vs last period</p>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-2 bg-card rounded-xl border border-border p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[15px] font-semibold text-foreground">Collection Trend</h3>
            <span className="text-[11px] text-muted-foreground flex items-center gap-1"><Calendar size={11} /> {period === "weekly" ? "This Week" : "This Year"}</span>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={period === "weekly" ? weeklyData : monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey={period === "weekly" ? "day" : "month"} tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={v => `₱${(v / 1000).toFixed(0)}k`} />
              <Tooltip formatter={(v: number) => fmt(v)} />
              <Line type="monotone" dataKey="amount" stroke="#c9a227" strokeWidth={2.5} dot={{ r: 4, fill: "#c9a227" }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-[15px] font-semibold text-foreground mb-4">Payment Methods</h3>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={paymentMethodData} dataKey="value" cx="50%" cy="45%" outerRadius={75} innerRadius={45}>
                {paymentMethodData.map(e => <Cell key={e.name} fill={e.color} />)}
              </Pie>
              <Legend iconType="circle" iconSize={8} formatter={v => <span style={{ fontSize: 12 }}>{v}</span>} />
              <Tooltip formatter={(v: number) => `${v}%`} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-[15px] font-semibold text-foreground mb-4">Collections by Course</h3>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={[{ course: "BSCS", amount: 68500 }, { course: "BSIT", amount: 43750 }, { course: "BSA", amount: 52300 }, { course: "BSBA", amount: 39600 }, { course: "BSED", amount: 27100 }]} barSize={28}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="course" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={v => `₱${(v / 1000).toFixed(0)}k`} />
              <Tooltip formatter={(v: number) => fmt(v)} />
              <Bar dataKey="amount" fill="#162347" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-[15px] font-semibold text-foreground mb-4">Fee Type Summary</h3>
          <div className="space-y-3">
            {[
              { type: "Tuition Fee", amount: 141200, pct: 58 },
              { type: "Miscellaneous", amount: 48600, pct: 20 },
              { type: "Lab Fee", amount: 24300, pct: 10 },
              { type: "Enrollment Fee", amount: 19400, pct: 8 },
              { type: "Other Fees", amount: 9700, pct: 4 },
            ].map(row => (
              <div key={row.type}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[12px] font-medium text-foreground">{row.type}</span>
                  <span className="text-[12px] text-muted-foreground">{fmt(row.amount)} · {row.pct}%</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-muted overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${row.pct}%`, background: "#c9a227" }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}

// ─── Page: Manage Faculty ─────────────────────────────────────────────────────

function ManageFacultyPage() {
  const [faculty, setFaculty] = useState<Faculty[]>(initialFaculty);
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [selected, setSelected] = useState<Faculty | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [editTarget, setEditTarget] = useState<Faculty | null>(null);
  const [form, setForm] = useState({ name: "", department: "", email: "", phone: "", status: "Active" as Faculty["status"], yearsExp: "" });
  const [confirmDelete, setConfirmDelete] = useState<Faculty | null>(null);
  const [saved, setSaved] = useState(false);

  const departments = ["All", ...Array.from(new Set(faculty.map(f => f.department)))];

  const filtered = faculty.filter(f => {
    const q = search.toLowerCase();
    return (
      (f.name.toLowerCase().includes(q) || f.id.toLowerCase().includes(q) || f.email.toLowerCase().includes(q)) &&
      (deptFilter === "All" || f.department === deptFilter) &&
      (statusFilter === "All" || f.status === statusFilter)
    );
  });

  function openAdd() {
    setForm({ name: "", department: "", email: "", phone: "", status: "Active", yearsExp: "" });
    setEditTarget(null);
    setSaved(false);
    setShowAdd(true);
  }

  function openEdit(f: Faculty) {
    setForm({ name: f.name, department: f.department, email: f.email, phone: f.phone, status: f.status, yearsExp: String(f.yearsExp) });
    setEditTarget(f);
    setSaved(false);
    setShowAdd(true);
  }

  function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (editTarget) {
      setFaculty(prev => prev.map(f => f.id === editTarget.id ? { ...f, ...form, yearsExp: Number(form.yearsExp) } : f));
      if (selected?.id === editTarget.id) setSelected(prev => prev ? { ...prev, ...form, yearsExp: Number(form.yearsExp) } : prev);
    } else {
      const newEntry: Faculty = {
        id: `FAC-00${faculty.length + 1}`,
        name: form.name, department: form.department, email: form.email,
        phone: form.phone, status: form.status, yearsExp: Number(form.yearsExp), subjects: [],
      };
      setFaculty(prev => [...prev, newEntry]);
    }
    setSaved(true);
    setTimeout(() => setShowAdd(false), 1000);
  }

  function handleDelete(f: Faculty) {
    setFaculty(prev => prev.filter(x => x.id !== f.id));
    if (selected?.id === f.id) setSelected(null);
    setConfirmDelete(null);
  }

  const activeCount = faculty.filter(f => f.status === "Active").length;
  const onLeaveCount = faculty.filter(f => f.status === "On Leave").length;

  return (
    <main className="flex-1 overflow-y-auto px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-[28px] font-semibold text-foreground">Manage Faculty</h1>
          <p className="text-sm text-muted-foreground mt-0.5">View and manage faculty members and instructors</p>
        </div>
        <button onClick={openAdd} className="flex items-center gap-2 px-4 py-2 rounded-lg text-white text-sm font-semibold hover:opacity-90 transition-colors" style={{ background: "#c9a227" }}>
          <Plus size={14} /> Add Faculty
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-4 mb-5">
        {[
          { label: "Total Faculty", value: faculty.length, icon: Users, color: "#2563eb", bg: "#dbeafe" },
          { label: "Active", value: activeCount, icon: UserCheck, color: "#16a34a", bg: "#dcfce7" },
          { label: "On Leave / Inactive", value: onLeaveCount + (faculty.length - activeCount - onLeaveCount), icon: Clock, color: "#d97706", bg: "#fef3c7" },
        ].map(c => (
          <div key={c.label} className="bg-card rounded-xl border border-border p-4 flex items-center gap-4">
            <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: c.bg }}>
              <c.icon size={18} style={{ color: c.color }} />
            </div>
            <div>
              <p className="text-[11px] text-muted-foreground font-semibold uppercase tracking-wide">{c.label}</p>
              <p className="text-[20px] font-semibold text-foreground">{c.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-card rounded-xl border border-border p-4 mb-4 flex flex-wrap gap-3 items-center">
        <div className="flex items-center gap-2 flex-1 min-w-[200px] border border-border rounded-lg px-3 py-2 bg-input-background">
          <Search size={14} className="text-muted-foreground" />
          <input className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground" placeholder="Search faculty..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="border border-border rounded-lg px-3 py-2 text-sm bg-input-background outline-none" value={deptFilter} onChange={e => setDeptFilter(e.target.value)}>
          {departments.map(d => <option key={d}>{d}</option>)}
        </select>
        <select className="border border-border rounded-lg px-3 py-2 text-sm bg-input-background outline-none" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
          {["All", "Active", "On Leave", "Inactive"].map(s => <option key={s}>{s}</option>)}
        </select>
        <span className="text-[12px] text-muted-foreground ml-auto">{filtered.length} member{filtered.length !== 1 ? "s" : ""}</span>
      </div>

      {/* Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                {["", "Faculty ID", "Name", "Department", "Email", "Subjects", "Exp.", "Status", ""].map((col, i) => (
                  <th key={i} className="text-left px-4 py-3 font-semibold text-muted-foreground uppercase tracking-wide text-[10px] whitespace-nowrap">{col}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={9} className="text-center py-12 text-muted-foreground text-sm">No faculty found.</td></tr>
              ) : filtered.map((f, i) => (
                <tr key={f.id} className={`hover:bg-muted/30 transition-colors ${i < filtered.length - 1 ? "border-b border-border" : ""}`}>
                  <td className="px-4 py-3"><Avatar name={f.name} size={32} /></td>
                  <td className="px-4 py-3 font-medium text-muted-foreground">{f.id}</td>
                  <td className="px-4 py-3 font-semibold text-foreground whitespace-nowrap">{f.name}</td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{f.department}</td>
                  <td className="px-4 py-3 text-muted-foreground">{f.email}</td>
                  <td className="px-4 py-3 text-muted-foreground">{f.subjects.length > 0 ? f.subjects.join(", ") : <span className="italic text-muted-foreground/50">None</span>}</td>
                  <td className="px-4 py-3 text-center text-muted-foreground">{f.yearsExp}y</td>
                  <td className="px-4 py-3"><StatusBadge status={f.status} /></td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <button onClick={() => setSelected(f)} className="p-1.5 rounded-lg hover:bg-blue-50 text-blue-500 transition-colors" title="View"><GraduationCap size={14} /></button>
                      <button onClick={() => openEdit(f)} className="p-1.5 rounded-lg hover:bg-amber-50 text-amber-500 transition-colors" title="Edit"><Edit2 size={14} /></button>
                      <button onClick={() => setConfirmDelete(f)} className="p-1.5 rounded-lg hover:bg-red-50 text-red-400 transition-colors" title="Delete"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setSelected(null)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-semibold">Faculty Profile</h3>
              <button onClick={() => setSelected(null)} className="p-1 rounded-lg hover:bg-muted"><X size={16} /></button>
            </div>
            <div className="flex items-center gap-4 mb-5 p-4 bg-muted/50 rounded-xl">
              <Avatar name={selected.name} size={48} />
              <div>
                <p className="font-semibold text-foreground">{selected.name}</p>
                <p className="text-sm text-muted-foreground">{selected.id} · {selected.department}</p>
                <StatusBadge status={selected.status} />
              </div>
            </div>
            <div className="space-y-3 mb-5">
              {[
                { label: "Email", value: selected.email, icon: Mail },
                { label: "Phone", value: selected.phone, icon: Phone },
                { label: "Experience", value: `${selected.yearsExp} years`, icon: GraduationCap },
              ].map(row => (
                <div key={row.label} className="flex items-center gap-3 border-b border-border pb-3">
                  <row.icon size={14} className="text-muted-foreground flex-shrink-0" />
                  <span className="text-sm text-muted-foreground w-24">{row.label}</span>
                  <span className="text-sm font-medium text-foreground">{row.value}</span>
                </div>
              ))}
              <div>
                <p className="text-sm text-muted-foreground mb-2">Subjects Handled</p>
                <div className="flex flex-wrap gap-2">
                  {selected.subjects.length > 0
                    ? selected.subjects.map(s => <span key={s} className="px-2.5 py-1 rounded-full text-[11px] font-medium bg-primary/10 text-primary">{s}</span>)
                    : <span className="text-sm text-muted-foreground italic">No subjects assigned</span>}
                </div>
              </div>
            </div>
            <button onClick={() => { openEdit(selected); setSelected(null); }} className="w-full py-2.5 rounded-lg text-white text-sm font-semibold hover:opacity-90" style={{ background: "#162347" }}>Edit Profile</button>
          </div>
        </div>
      )}

      {/* Add / Edit Modal */}
      {showAdd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 p-6">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-semibold">{editTarget ? "Edit Faculty" : "Add Faculty"}</h3>
              <button onClick={() => setShowAdd(false)} className="p-1 rounded-lg hover:bg-muted"><X size={16} /></button>
            </div>
            {saved ? (
              <div className="flex flex-col items-center gap-3 py-8">
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center"><Check size={24} className="text-green-600" /></div>
                <p className="font-semibold text-foreground">{editTarget ? "Changes Saved!" : "Faculty Added!"}</p>
              </div>
            ) : (
              <form onSubmit={handleSave} className="flex flex-col gap-4">
                {[
                  { label: "Full Name", key: "name", placeholder: "e.g. Dr. Juan dela Cruz" },
                  { label: "Department", key: "department", placeholder: "e.g. Computer Science" },
                  { label: "Email", key: "email", placeholder: "e.g. j.delacruz@pclu.edu" },
                  { label: "Phone", key: "phone", placeholder: "e.g. 09171234567" },
                  { label: "Years of Experience", key: "yearsExp", placeholder: "e.g. 5" },
                ].map(field => (
                  <div key={field.key}>
                    <label className="text-[13px] font-medium text-muted-foreground mb-1 block">{field.label}</label>
                    <input
                      className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-input-background outline-none focus:ring-2 focus:ring-ring/30"
                      placeholder={field.placeholder}
                      value={(form as any)[field.key]}
                      onChange={e => setForm({ ...form, [field.key]: e.target.value })}
                      required
                    />
                  </div>
                ))}
                <div>
                  <label className="text-[13px] font-medium text-muted-foreground mb-1 block">Status</label>
                  <select className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-input-background outline-none" value={form.status} onChange={e => setForm({ ...form, status: e.target.value as Faculty["status"] })}>
                    {["Active", "On Leave", "Inactive"].map(s => <option key={s}>{s}</option>)}
                  </select>
                </div>
                <div className="flex gap-3 mt-1">
                  <button type="button" onClick={() => setShowAdd(false)} className="flex-1 py-2 rounded-lg border border-border text-sm font-medium text-muted-foreground hover:bg-muted transition-colors">Cancel</button>
                  <button type="submit" className="flex-1 py-2 rounded-lg text-sm font-semibold text-white" style={{ background: "#162347" }}>{editTarget ? "Save Changes" : "Add Faculty"}</button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Confirm Delete */}
      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm mx-4 p-6 text-center">
            <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4"><Trash2 size={20} className="text-red-500" /></div>
            <h3 className="text-lg font-semibold mb-2">Delete Faculty?</h3>
            <p className="text-sm text-muted-foreground mb-5">This will permanently remove <strong>{confirmDelete.name}</strong> from the system.</p>
            <div className="flex gap-3">
              <button onClick={() => setConfirmDelete(null)} className="flex-1 py-2 rounded-lg border border-border text-sm font-medium text-muted-foreground hover:bg-muted">Cancel</button>
              <button onClick={() => handleDelete(confirmDelete)} className="flex-1 py-2 rounded-lg text-sm font-semibold text-white bg-red-500 hover:bg-red-600">Delete</button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

// ─── Page: Manage Class List ──────────────────────────────────────────────────

function ManageClassListPage() {
  const [classes, setClasses] = useState<ClassItem[]>(initialClasses);
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("All");
  const [selected, setSelected] = useState<ClassItem | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [editTarget, setEditTarget] = useState<ClassItem | null>(null);
  const [form, setForm] = useState({ code: "", name: "", instructor: "", department: "", units: "3", capacity: "40", schedule: "", room: "" });
  const [confirmDelete, setConfirmDelete] = useState<ClassItem | null>(null);
  const [saved, setSaved] = useState(false);

  const departments = ["All", ...Array.from(new Set(classes.map(c => c.department)))];

  const filtered = classes.filter(c => {
    const q = search.toLowerCase();
    return (
      (c.name.toLowerCase().includes(q) || c.code.toLowerCase().includes(q) || c.instructor.toLowerCase().includes(q)) &&
      (deptFilter === "All" || c.department === deptFilter)
    );
  });

  function openAdd() {
    setForm({ code: "", name: "", instructor: "", department: "", units: "3", capacity: "40", schedule: "", room: "" });
    setEditTarget(null);
    setSaved(false);
    setShowAdd(true);
  }

  function openEdit(c: ClassItem) {
    setForm({ code: c.code, name: c.name, instructor: c.instructor, department: c.department, units: String(c.units), capacity: String(c.capacity), schedule: c.schedule, room: c.room });
    setEditTarget(c);
    setSaved(false);
    setShowAdd(true);
  }

  function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (editTarget) {
      setClasses(prev => prev.map(c => c.id === editTarget.id ? { ...c, ...form, units: Number(form.units), capacity: Number(form.capacity) } : c));
      if (selected?.id === editTarget.id) setSelected(prev => prev ? { ...prev, ...form, units: Number(form.units), capacity: Number(form.capacity) } : prev);
    } else {
      setClasses(prev => [...prev, {
        id: `CLS-00${prev.length + 1}`, code: form.code, name: form.name, instructor: form.instructor,
        department: form.department, units: Number(form.units), enrolled: 0, capacity: Number(form.capacity),
        schedule: form.schedule, room: form.room, students: [],
      }]);
    }
    setSaved(true);
    setTimeout(() => setShowAdd(false), 1000);
  }

  function handleDelete(c: ClassItem) {
    setClasses(prev => prev.filter(x => x.id !== c.id));
    if (selected?.id === c.id) setSelected(null);
    setConfirmDelete(null);
  }

  const totalEnrolled = classes.reduce((a, c) => a + c.enrolled, 0);
  const totalCapacity = classes.reduce((a, c) => a + c.capacity, 0);

  return (
    <main className="flex-1 overflow-y-auto px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-[28px] font-semibold text-foreground">Manage Class List</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage subjects, instructors, and enrolled students</p>
        </div>
        <button onClick={openAdd} className="flex items-center gap-2 px-4 py-2 rounded-lg text-white text-sm font-semibold hover:opacity-90" style={{ background: "#c9a227" }}>
          <Plus size={14} /> Add Class
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-4 mb-5">
        {[
          { label: "Total Classes", value: classes.length, icon: BookOpen, color: "#2563eb", bg: "#dbeafe" },
          { label: "Total Enrolled", value: totalEnrolled, icon: Users, color: "#16a34a", bg: "#dcfce7" },
          { label: "Seat Utilization", value: `${Math.round((totalEnrolled / totalCapacity) * 100)}%`, icon: BookMarked, color: "#d97706", bg: "#fef3c7" },
        ].map(c => (
          <div key={c.label} className="bg-card rounded-xl border border-border p-4 flex items-center gap-4">
            <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: c.bg }}>
              <c.icon size={18} style={{ color: c.color }} />
            </div>
            <div>
              <p className="text-[11px] text-muted-foreground font-semibold uppercase tracking-wide">{c.label}</p>
              <p className="text-[20px] font-semibold text-foreground">{c.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-card rounded-xl border border-border p-4 mb-4 flex flex-wrap gap-3 items-center">
        <div className="flex items-center gap-2 flex-1 min-w-[200px] border border-border rounded-lg px-3 py-2 bg-input-background">
          <Search size={14} className="text-muted-foreground" />
          <input className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground" placeholder="Search by name, code, or instructor..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="border border-border rounded-lg px-3 py-2 text-sm bg-input-background outline-none" value={deptFilter} onChange={e => setDeptFilter(e.target.value)}>
          {departments.map(d => <option key={d}>{d}</option>)}
        </select>
        <span className="text-[12px] text-muted-foreground ml-auto">{filtered.length} class{filtered.length !== 1 ? "es" : ""}</span>
      </div>

      {/* Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                {["Code", "Subject Name", "Instructor", "Dept.", "Units", "Enrolled", "Schedule", "Room", ""].map((col, i) => (
                  <th key={i} className="text-left px-4 py-3 font-semibold text-muted-foreground uppercase tracking-wide text-[10px] whitespace-nowrap">{col}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={9} className="text-center py-12 text-muted-foreground text-sm">No classes found.</td></tr>
              ) : filtered.map((c, i) => {
                const pct = Math.round((c.enrolled / c.capacity) * 100);
                return (
                  <tr key={c.id} className={`hover:bg-muted/30 transition-colors ${i < filtered.length - 1 ? "border-b border-border" : ""}`}>
                    <td className="px-4 py-3 font-bold text-primary whitespace-nowrap">{c.code}</td>
                    <td className="px-4 py-3 font-medium text-foreground">{c.name}</td>
                    <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{c.instructor}</td>
                    <td className="px-4 py-3 text-muted-foreground">{c.department}</td>
                    <td className="px-4 py-3 text-center text-muted-foreground">{c.units}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <span className="text-foreground font-medium">{c.enrolled}/{c.capacity}</span>
                        <div className="w-16 h-1.5 rounded-full bg-muted overflow-hidden">
                          <div className="h-full rounded-full" style={{ width: `${pct}%`, background: pct > 90 ? "#ef4444" : "#c9a227" }} />
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{c.schedule}</td>
                    <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{c.room}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <button onClick={() => setSelected(c)} className="p-1.5 rounded-lg hover:bg-blue-50 text-blue-500 transition-colors"><BookOpen size={14} /></button>
                        <button onClick={() => openEdit(c)} className="p-1.5 rounded-lg hover:bg-amber-50 text-amber-500 transition-colors"><Edit2 size={14} /></button>
                        <button onClick={() => setConfirmDelete(c)} className="p-1.5 rounded-lg hover:bg-red-50 text-red-400 transition-colors"><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Class Detail Modal */}
      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setSelected(null)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 p-6 max-h-[80vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-semibold">Class Details</h3>
              <button onClick={() => setSelected(null)} className="p-1 rounded-lg hover:bg-muted"><X size={16} /></button>
            </div>
            <div className="p-4 rounded-xl mb-5" style={{ background: "#f0f4ff" }}>
              <p className="text-[11px] font-bold text-primary uppercase tracking-widest mb-1">{selected.code}</p>
              <p className="font-semibold text-foreground text-[17px]">{selected.name}</p>
              <p className="text-sm text-muted-foreground">{selected.department} · {selected.units} units</p>
            </div>
            <div className="space-y-3 mb-5">
              {[
                { label: "Instructor", value: selected.instructor },
                { label: "Schedule", value: selected.schedule },
                { label: "Room", value: selected.room },
                { label: "Enrollment", value: `${selected.enrolled} / ${selected.capacity}` },
              ].map(row => (
                <div key={row.label} className="flex items-center justify-between border-b border-border pb-3">
                  <span className="text-sm text-muted-foreground">{row.label}</span>
                  <span className="text-sm font-semibold text-foreground">{row.value}</span>
                </div>
              ))}
            </div>
            <p className="text-[13px] font-semibold text-foreground mb-2">Enrolled Students ({selected.students.length})</p>
            {selected.students.length === 0
              ? <p className="text-sm text-muted-foreground italic">No students listed.</p>
              : (
                <div className="flex flex-col gap-2">
                  {selected.students.map(s => (
                    <div key={s} className="flex items-center gap-3 p-2 rounded-lg bg-muted/50">
                      <Avatar name={s} size={28} />
                      <span className="text-sm text-foreground">{s}</span>
                    </div>
                  ))}
                </div>
              )}
          </div>
        </div>
      )}

      {/* Add / Edit Modal */}
      {showAdd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-semibold">{editTarget ? "Edit Class" : "Add Class"}</h3>
              <button onClick={() => setShowAdd(false)} className="p-1 rounded-lg hover:bg-muted"><X size={16} /></button>
            </div>
            {saved ? (
              <div className="flex flex-col items-center gap-3 py-8">
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center"><Check size={24} className="text-green-600" /></div>
                <p className="font-semibold text-foreground">{editTarget ? "Class Updated!" : "Class Added!"}</p>
              </div>
            ) : (
              <form onSubmit={handleSave} className="flex flex-col gap-4">
                {[
                  { label: "Subject Code", key: "code", placeholder: "e.g. CS301" },
                  { label: "Subject Name", key: "name", placeholder: "e.g. Data Structures" },
                  { label: "Instructor", key: "instructor", placeholder: "e.g. Dr. Elena Cruz" },
                  { label: "Department", key: "department", placeholder: "e.g. BSCS" },
                  { label: "Units", key: "units", placeholder: "e.g. 3" },
                  { label: "Capacity", key: "capacity", placeholder: "e.g. 40" },
                  { label: "Schedule", key: "schedule", placeholder: "e.g. MWF 7:30–8:30 AM" },
                  { label: "Room", key: "room", placeholder: "e.g. Room 201" },
                ].map(field => (
                  <div key={field.key}>
                    <label className="text-[13px] font-medium text-muted-foreground mb-1 block">{field.label}</label>
                    <input className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-input-background outline-none focus:ring-2 focus:ring-ring/30" placeholder={field.placeholder} value={(form as any)[field.key]} onChange={e => setForm({ ...form, [field.key]: e.target.value })} required />
                  </div>
                ))}
                <div className="flex gap-3 mt-1">
                  <button type="button" onClick={() => setShowAdd(false)} className="flex-1 py-2 rounded-lg border border-border text-sm font-medium text-muted-foreground hover:bg-muted">Cancel</button>
                  <button type="submit" className="flex-1 py-2 rounded-lg text-sm font-semibold text-white" style={{ background: "#162347" }}>{editTarget ? "Save Changes" : "Add Class"}</button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Confirm Delete */}
      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm mx-4 p-6 text-center">
            <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4"><Trash2 size={20} className="text-red-500" /></div>
            <h3 className="text-lg font-semibold mb-2">Delete Class?</h3>
            <p className="text-sm text-muted-foreground mb-5">This will remove <strong>{confirmDelete.code} – {confirmDelete.name}</strong> from the system.</p>
            <div className="flex gap-3">
              <button onClick={() => setConfirmDelete(null)} className="flex-1 py-2 rounded-lg border border-border text-sm font-medium text-muted-foreground hover:bg-muted">Cancel</button>
              <button onClick={() => handleDelete(confirmDelete)} className="flex-1 py-2 rounded-lg text-sm font-semibold text-white bg-red-500 hover:bg-red-600">Delete</button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

// ─── Page: View Schedule ──────────────────────────────────────────────────────

function parseSchedule(schedule: string): { days: string[]; startSlot: number; span: number } {
  const dayMap: Record<string, string[]> = {
    MWF: ["Monday", "Wednesday", "Friday"],
    TTh: ["Tuesday", "Thursday"],
    MW: ["Monday", "Wednesday"],
    TThS: ["Tuesday", "Thursday", "Saturday"],
  };
  let days: string[] = [];
  for (const key of Object.keys(dayMap)) {
    if (schedule.startsWith(key)) { days = dayMap[key]; break; }
  }
  const timeMatch = schedule.match(/(\d+):(\d+)\s*(AM|PM)/i);
  if (!timeMatch) return { days, startSlot: 0, span: 1 };
  let hour = parseInt(timeMatch[1]);
  const min = parseInt(timeMatch[2]);
  const meridiem = timeMatch[3].toUpperCase();
  if (meridiem === "PM" && hour !== 12) hour += 12;
  if (meridiem === "AM" && hour === 12) hour = 0;
  const startMinutes = hour * 60 + min;
  const baseMinutes = 7 * 60 + 30;
  const startSlot = Math.round((startMinutes - baseMinutes) / 60);
  return { days, startSlot: Math.max(0, startSlot), span: 2 };
}

function ViewSchedulePage() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [deptFilter, setDeptFilter] = useState("All");

  const departments = ["All", ...Array.from(new Set(initialClasses.map(c => c.department)))];
  const filtered = deptFilter === "All" ? initialClasses : initialClasses.filter(c => c.department === deptFilter);

  // Build grid: day → slot → class[]
  const grid: Record<string, Record<number, ClassItem[]>> = {};
  DAYS.forEach(d => { grid[d] = {}; TIME_SLOTS.forEach((_, i) => { grid[d][i] = []; }); });
  filtered.forEach(cls => {
    const { days, startSlot } = parseSchedule(cls.schedule);
    days.forEach(day => {
      if (grid[day] && grid[day][startSlot] !== undefined) {
        grid[day][startSlot].push(cls);
      }
    });
  });

  const colorMap: Record<string, typeof CLASS_COLORS[0]> = {};
  initialClasses.forEach((c, i) => { colorMap[c.id] = CLASS_COLORS[i % CLASS_COLORS.length]; });

  return (
    <main className="flex-1 overflow-y-auto px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-[28px] font-semibold text-foreground">View Schedule</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Weekly class timetable for A.Y. 2026–2027, 1st Semester</p>
        </div>
        <div className="flex items-center gap-2">
          <select className="border border-border rounded-lg px-3 py-2 text-sm bg-card outline-none" value={deptFilter} onChange={e => setDeptFilter(e.target.value)}>
            {departments.map(d => <option key={d}>{d}</option>)}
          </select>
          <div className="flex rounded-lg border border-border overflow-hidden">
            {(["grid", "list"] as const).map(m => (
              <button key={m} onClick={() => setViewMode(m)} className="px-4 py-2 text-sm font-medium capitalize transition-colors" style={viewMode === m ? { background: "#162347", color: "#fff" } : { background: "white", color: "#6b7280" }}>
                {m === "grid" ? "Timetable" : "List"}
              </button>
            ))}
          </div>
          <button className="flex items-center gap-2 px-3 py-2 rounded-lg border border-border text-sm font-medium text-muted-foreground hover:bg-muted transition-colors">
            <Download size={14} /> Export
          </button>
        </div>
      </div>

      {viewMode === "grid" ? (
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-[12px] min-w-[700px]">
              <thead>
                <tr style={{ background: "#162347" }}>
                  <th className="text-left px-4 py-3 font-semibold text-white/60 uppercase tracking-wide text-[10px] w-24">Time</th>
                  {DAYS.map(d => (
                    <th key={d} className="text-center px-3 py-3 font-semibold text-white text-[11px]">{d}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {TIME_SLOTS.map((slot, slotIdx) => (
                  <tr key={slot} className={slotIdx % 2 === 0 ? "bg-white" : "bg-muted/20"}>
                    <td className="px-4 py-2 font-medium text-muted-foreground border-r border-border whitespace-nowrap align-top pt-3">{slot}</td>
                    {DAYS.map(day => {
                      const classes = grid[day]?.[slotIdx] ?? [];
                      return (
                        <td key={day} className="px-2 py-1.5 align-top border-l border-border/50 min-w-[130px]">
                          {classes.map(cls => {
                            const col = colorMap[cls.id];
                            return (
                              <div key={cls.id} className="rounded-lg px-2 py-1.5 mb-1 border" style={{ background: col.bg, borderColor: col.border }}>
                                <p className="font-bold text-[10px]" style={{ color: col.text }}>{cls.code}</p>
                                <p className="font-medium text-[11px] leading-tight" style={{ color: col.text }}>{cls.name}</p>
                                <p className="text-[10px] opacity-70" style={{ color: col.text }}>{cls.room}</p>
                              </div>
                            );
                          })}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {/* Legend */}
          <div className="px-4 py-3 border-t border-border bg-muted/30">
            <div className="flex flex-wrap gap-3">
              {filtered.map((cls, i) => {
                const col = CLASS_COLORS[initialClasses.findIndex(c => c.id === cls.id) % CLASS_COLORS.length];
                return (
                  <div key={cls.id} className="flex items-center gap-1.5">
                    <div className="w-3 h-3 rounded-sm border flex-shrink-0" style={{ background: col.bg, borderColor: col.border }} />
                    <span className="text-[11px] text-muted-foreground">{cls.code} – {cls.instructor.split(" ").slice(-1)[0]}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {filtered.map((cls, i) => {
            const col = CLASS_COLORS[initialClasses.findIndex(c => c.id === cls.id) % CLASS_COLORS.length];
            return (
              <div key={cls.id} className="bg-card rounded-xl border border-border p-5 flex items-start gap-5">
                <div className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0 font-bold text-[13px] border" style={{ background: col.bg, borderColor: col.border, color: col.text }}>
                  {cls.code.replace(/[A-Z]+/, "").trim() || cls.code.slice(0, 3)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-4 flex-wrap">
                    <div>
                      <p className="font-bold text-[11px] tracking-widest uppercase" style={{ color: col.text }}>{cls.code}</p>
                      <p className="font-semibold text-foreground text-[15px]">{cls.name}</p>
                      <p className="text-sm text-muted-foreground">{cls.instructor}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold text-foreground">{cls.department}</p>
                      <p className="text-[12px] text-muted-foreground">{cls.units} units</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-4 mt-3">
                    {[
                      { icon: Calendar, text: cls.schedule },
                      { icon: BookMarked, text: cls.room },
                      { icon: Users, text: `${cls.enrolled} / ${cls.capacity} students` },
                    ].map((item, j) => (
                      <div key={j} className="flex items-center gap-1.5 text-[12px] text-muted-foreground">
                        <item.icon size={12} />
                        {item.text}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </main>
  );
}

// ─── Nav ──────────────────────────────────────────────────────────────────────

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard View", page: "dashboard" },
  { icon: GraduationCap, label: "Manage Faculty", page: "faculty" },
  { icon: BookOpen, label: "Manage Class List", page: "classes" },
  { icon: Calendar, label: "View Schedule", page: "schedule" },
  { icon: FileText, label: "Reports", page: "reports" },
];

// ─── Root ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activePage, setActivePage] = useState("dashboard");
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  return (
    <div className="flex h-screen w-full overflow-hidden" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Sidebar */}
      <aside className="flex flex-col h-full transition-all duration-300 flex-shrink-0" style={{ width: sidebarOpen ? 220 : 0, minWidth: sidebarOpen ? 220 : 0, background: "#162347", overflow: "hidden" }}>
        <div className="flex items-center gap-3 px-5 py-5 border-b border-white/10">
          <div className="flex items-center justify-center rounded-lg flex-shrink-0" style={{ width: 36, height: 36, background: "#c9a227" }}>
            <CreditCard size={18} color="#fff" />
          </div>
          <div className="leading-tight">
            <p className="text-white/50 text-[10px] font-semibold tracking-widest uppercase">PCLU</p>
            <p className="text-white text-sm font-bold leading-none">OptimaSched</p>
          </div>
        </div>
        <div className="mx-3 mt-4 mb-2 rounded-xl px-3 py-3 flex items-center gap-3 cursor-pointer hover:bg-white/10 transition-colors" style={{ background: "rgba(255,255,255,0.07)" }}>
          <div className="flex items-center justify-center rounded-full flex-shrink-0 text-white font-bold text-sm" style={{ width: 36, height: 36, background: "#c9a227" }}>C</div>
          <div className="flex-1 min-w-0">
            <p className="text-white text-sm font-semibold truncate leading-tight">Cashier User</p>
            <p className="text-[11px] leading-tight" style={{ color: "#c9a227" }}>cashier</p>
          </div>
          <ChevronRight size={14} color="rgba(255,255,255,0.4)" />
        </div>
        <div className="px-3 mt-4 flex-1 overflow-y-auto">
          <p className="text-white/30 text-[10px] font-semibold tracking-widest uppercase px-2 mb-2">Navigation</p>
          <nav className="flex flex-col gap-1">
            {navItems.map(item => {
              const active = activePage === item.page;
              return (
                <button key={item.label} onClick={() => setActivePage(item.page)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-lg w-full text-left transition-colors text-[13px] font-medium"
                  style={active
                    ? { background: "rgba(255,255,255,0.12)", color: "#fff", borderLeft: "3px solid #c9a227" }
                    : { color: "rgba(255,255,255,0.55)", borderLeft: "3px solid transparent" }}>
                  <item.icon size={16} />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
        <div className="px-3 pb-5 pt-2">
          <button className="flex items-center gap-3 px-3 py-2.5 w-full rounded-lg text-[13px] transition-colors hover:bg-white/10" style={{ color: "rgba(255,255,255,0.45)" }}>
            <LogOut size={15} /><span>Disconnect Session</span>
          </button>
        </div>
      </aside>

      {/* Collapse Toggle */}
      <div className="relative flex-shrink-0" style={{ zIndex: 10 }}>
        <button onClick={() => setSidebarOpen(!sidebarOpen)}
          className="absolute top-1/2 -translate-y-1/2 flex items-center justify-center rounded-full shadow-md border border-gray-200 bg-white hover:bg-gray-50"
          style={{ left: -14, width: 28, height: 28 }}>
          {sidebarOpen ? <ChevronLeft size={14} className="text-gray-500" /> : <ChevronRight size={14} className="text-gray-500" />}
        </button>
      </div>

      {/* Main */}
      <div className="flex-1 flex flex-col h-full overflow-hidden bg-background">
        <header className="flex items-center justify-between px-8 py-4 bg-white border-b border-border flex-shrink-0">
          <h2 className="text-[15px] font-semibold text-foreground tracking-tight">PCLU Academic Control Workspace</h2>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-border text-[12px] font-medium text-foreground">
              <span className="w-2 h-2 rounded-full bg-amber-400 inline-block"></span>
              A.Y. 2026–2027
            </div>
            <div className="flex items-center justify-center rounded-full text-white font-bold text-sm" style={{ width: 34, height: 34, background: "#c9a227" }}>C</div>
          </div>
        </header>

        {activePage === "dashboard" && <DashboardPage onNewPayment={() => setShowPaymentModal(true)} />}
        {activePage === "faculty" && <ManageFacultyPage />}
        {activePage === "classes" && <ManageClassListPage />}
        {activePage === "schedule" && <ViewSchedulePage />}
        {activePage === "reports" && <ReportsPage />}
      </div>

      {showPaymentModal && <AddPaymentModal onClose={() => setShowPaymentModal(false)} />}
    </div>
  );
}
